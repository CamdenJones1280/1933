public class LinkedList<T extends Comparable<T>> implements List<T> {
    private boolean isSorted = true;
    private Node<T> head;
    private int size;

    public LinkedList() {
        head = new Node<T>(null, null);
        size = 0;

    }

    @Override
    public boolean add(T element) {
        if (element != null) {
            if (head == null) {
                head = new Node<T>(element);
            } else {
                Node<T> currNode = head;
                while (currNode.getNext() != null) {
                    currNode = currNode.getNext();
                }
                currNode.setNext(new Node<T>(element));
            }
            size++;
            if(size() < 2){
                isSorted = true;
            } else{
                Node<T> sortChecker = head.getNext();
                isSorted = true;
                while(sortChecker.getNext() != null) {
                    if (sortChecker.getData().compareTo(sortChecker.getNext().getData()) > 0) {
                        isSorted = false;
                    }
                    sortChecker = sortChecker.getNext();
                }
            }
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean add(int index, T element) {
        if (element == null || index < 0 || index >= size())
            return false;
        else {
            isSorted = false;
            if (index == 0) {
                head.setNext(new Node<T>(element,head.getNext()));
                size++;
                if(size() < 2){
                    isSorted = true;
                } else{
                    Node<T> sortChecker = head.getNext();
                    isSorted = true;
                    while(sortChecker.getNext() != null) {
                        if (sortChecker.getData().compareTo(sortChecker.getNext().getData()) > 0) {
                            isSorted = false;
                        }
                        sortChecker = sortChecker.getNext();
                    }
                }
                return true;
            }
            else if(index == size()){
                Node<T> currNode = head;
                while(currNode.getNext() != null){
                    currNode = currNode.getNext();
                }
                currNode.setNext(new Node<T>(element));
                size++;
                if(size() < 2){
                    isSorted = true;
                } else{
                    Node<T> sortChecker = head.getNext();
                    isSorted = true;
                    while(sortChecker.getNext() != null) {
                        if (sortChecker.getData().compareTo(sortChecker.getNext().getData()) > 0) {
                            isSorted = false;
                        }
                        sortChecker = sortChecker.getNext();
                    }
                }
                return true;
            }
            else {
                Node<T> currNode = head.getNext();
                for (int i = 0; i < index - 1; i++) {
                    currNode = currNode.getNext();
                }
                currNode.setNext(new Node<T>(element, currNode.getNext()));
                size++;
                if(size() < 2){
                    isSorted = true;
                } else{
                    Node<T> sortChecker = head.getNext();
                    isSorted = true;
                    while(sortChecker.getNext() != null) {
                        if (sortChecker.getData().compareTo(sortChecker.getNext().getData()) > 0) {
                            isSorted = false;
                        }
                        sortChecker = sortChecker.getNext();
                    }
                }
                return true;
            }
        }
    }

    @Override
    public void clear() {
        head = new Node<T>(null, null);
        size = 0;
        isSorted = true;

    }

    @Override
    public T get(int index) {
        if(index > size() || index < 0)
            return null;
        else{
            Node<T> currNode = head;
            for(int i = 0; i < size(); i++){
                currNode = currNode.getNext();
                if(i == index){
                    return currNode.getData();
                }
            }
        }
        return null;
    }

    @Override
    public int indexOf(T element) {
        if (element != null) {
            Node<T> currNode = head;
            if (currNode.getData() == element) {
                return 0;
            } else {
                for (int i = 0; i < size(); i++) {
                    currNode = currNode.getNext();
                    if(currNode.getData() == element){
                        return i;
                    }
                }
            }
            return -1;
        } else {
            return -1;
        }
    }

    @Override
    public boolean isEmpty() {
        if(size() == 0)
            return true;
        else
            return false;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public void sort() {
        if (isSorted != true) {
            Node<T> first = head.getNext();
            Node<T> min;
            while(first.getNext() != null){
                min = first;
                for (Node<T> others = first; others != null; others = others.getNext()) {
                    if (min.getData().compareTo(others.getData()) > 0) {
                        min = others;
                    }
                }
                Node<T> container = new Node<T>(first.getData(), null);
                first.setData(min.getData());
                min.setData(container.getData());
                first = first.getNext();
            }
        }
        isSorted = true;
    }

    @Override
    public T remove(int index) {
        T removedData;
        if(index >= size() || index < 0) {
            return null;
        }
        else if(index == 0){
            removedData = head.getNext().getData();
            head.setNext(head.getNext().getNext());
            size--;
            if(size() < 2){
                isSorted = true;
            } else{
                Node<T> sortChecker = head.getNext();
                isSorted = true;
                while(sortChecker.getNext() != null) {
                    if (sortChecker.getData().compareTo(sortChecker.getNext().getData()) > 0) {
                        isSorted = false;
                    }
                    sortChecker = sortChecker.getNext();
                }
            }
            return removedData;
        }
        else{
            Node<T> currNode = head;
            for(int i = 0; i < index; i++){
                currNode = currNode.getNext();
            }
            removedData = currNode.getNext().getData();
            Node<T> joiner = currNode.getNext();
            currNode.setNext(joiner.getNext());
            size--;
        }
        if(size() < 2){
            isSorted = true;
        } else{
            Node<T> sortChecker = head.getNext();
            isSorted = true;
            while(sortChecker.getNext() != null) {
                if (sortChecker.getData().compareTo(sortChecker.getNext().getData()) > 0) {
                    isSorted = false;
                }
                sortChecker = sortChecker.getNext();
            }
        }
        return removedData;
    }

    @Override
    public void equalTo(T element) {
        if (element != null) {
            Node<T> currNode = head;
            while(currNode.getNext() != null){
                if (currNode.getNext().getData() == element) {
                    currNode = currNode.getNext();
                } else {
                    currNode.setNext(currNode.getNext().getNext());
                    size--;
                }
            }
        }
        isSorted = true;
    }

    @Override
    public void reverse() {
        Node<T> ptr = head.getNext().getNext();
        Node<T> trailer = head.getNext();
        while(trailer.getNext() != null){
            trailer.setNext(ptr.getNext());
            ptr.setNext(head.getNext());
            head.setNext(ptr);
            ptr = trailer.getNext();
        }
        if(size() < 2){
            isSorted = true;
        } else{
            Node<T> sortChecker = head.getNext();
            isSorted = true;
            while(sortChecker.getNext() != null) {
                if (sortChecker.getData().compareTo(sortChecker.getNext().getData()) > 0) {
                    isSorted = false;
                }
                sortChecker = sortChecker.getNext();
            }
        }

    }

    @Override
    public void merge(List<T> otherList) {
        LinkedList other = (LinkedList) otherList;
        sort();
        other.sort();
        Node<T> firstList = head.getNext();
        Node<T> secondList = other.head.getNext();
        Node<T> temp = secondList;
        while(firstList.getNext() != null){
            while ((secondList.getNext() != null)){
                if(firstList.getData().compareTo(secondList.getData()) > 0){
                    firstList = new Node<T>(secondList.getData(), firstList);
                    firstList = firstList.getNext();
                }
                secondList = secondList.getNext();
            }
            temp = temp.getNext();
            secondList = temp;
            firstList = firstList.getNext();
        }
    }

    @Override
    public boolean rotate(int n) {
        return false;
    }

    @Override
    public boolean isSorted() {
        return isSorted;
    }

    @Override
    public String toString() {
        String string = "";
        Node<T> currNode = head;
        for(int i = 0; i <= size(); i++){
            string += currNode.getData() + " ";
            currNode = currNode.getNext();
        }
        return string;
    }

    public static void main(String[] args){
        List<String> list = new LinkedList<>();
        list.add("one Piece");
        list.add("Fullmetal Alchemist");
        list.add("Attack On Titan");
        list.add("Tokyo Ghoul");
        list.add("Haikyuu!!");
        list.add("Mob Psycho");
        list.add("Hunter x Hunter");
        List<String> list2 = new LinkedList<>();
        list2.add("The Promised Neverland");
        list2.add("Solo Leveling");
        list2.add("The Breaker");
        list2.add("One Punch Man");
        list2.add("Dragon Ball Z");
        list2.add("JoJo's Bizarre Adventure");
        list2.add("Yuri!!! on ICE");
        list.merge(list2);
        System.out.println(list);
    }
}