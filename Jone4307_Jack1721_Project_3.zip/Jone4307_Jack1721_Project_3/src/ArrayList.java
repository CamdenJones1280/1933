//written by Camden Jones, JONE4307
// written by Logan Jackson, JACK1721
public class ArrayList<T extends Comparable<T>> implements List<T> {

    private boolean isSorted = true;
    private T[] a;
    private int inList;

    //basic constructor with a default of 2
    public ArrayList() {
        a = (T[]) new Comparable[2];
    }

    //this makes a new array of double the size of the last one, used as a helper function
    private void reSize(){
        T[] reSized = (T[]) new Comparable[a.length * 2];
        for(int i = 0; i < a.length; i++){
            reSized[i] = a[i];
        }
        a = reSized;
    }
    //helper function that updates issorted in needed methods
    private Boolean SortCheck(){
        //updates inList
        size();
        //loops though the elements in the list and compares it to the next on, if next is bigger it ends the loop
        for(int i = 0; i < inList-1; i++){
            if(a[i].compareTo(a[i+1]) <= 0){
                isSorted = true;
            }else{
                return false;
            }
        }
        return true;
    }

    public boolean add(T element) {
        size();
        //checks for valid input
        if(element == null){
            return false;
        }
        //walks through the list and find the next null spot
        else{
            for(int i = 0; i < a.length; i++){
                if(a[i] == null){
                    a[i] = element;
                    isSorted = SortCheck();
                    return true;
                }
            }
            //resizes the array if it cant find an open null spot
            reSize();
            for(int i = 0; i < a.length; i++){
                if(a[i] == null){
                    a[i] = element;
                    isSorted = SortCheck();
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean add(int index, T element) {
        //updates the size of elements in the list
        size();
        //resizes array if needed and checks for valid input
        if(inList == a.length -1){
            reSize();
        }
        if(index >= inList || index < 0){
            return false;
        }
        if(element == null){
            return false;
        }
        //inserts number at index and shifts all the others
        T holder = a[index +1];
        T holder2;
            for(int i=0; i < inList +1 ; i++) {
                if( i == index) {
                    holder = a[i];
                    a[i] = element;
                } else if(i > index){
                    holder2 = a[i];
                    a[i] = holder;
                    holder = holder2;
                }
            }
        isSorted = SortCheck();
        return true;
    }

    @Override
    public void clear() {
        //walks through list and turns everything to null
        for(int i=0; i < a.length; i++){
            a[i] = null;
        }
        isSorted = true;
    }

    @Override
    public T get(int index) {
        //checks for valid input
        if(index > a.length - 1 || index < 0){
            return null;
        }
        //finds element at that index
        T element = a[index];
        return element;
    }

    @Override
    public int indexOf(T element) {
        //checks for valid input and walks down the list to find the element, returns the index
        if(element != null) {
            for (int i = 0; i < a.length; i++) {
                if (element == a[i]) {
                    return i;
                }
            }
            //handles null case
        }else if(element == null){
            return -1;
        }
        return -1;
    }

    @Override
    public boolean isEmpty() {
        //walks through list and finds makes sure every element is null
        for(int i = 0; i < a.length; i++){
            if(a[i] != null){
                return false;
            }
        }
        return true;
    }

    @Override
    public int size() {
        //walks through list and counts how many elements are something other than null, updates variable inList
        inList = 0;
        for(int i=0; i < a.length; i++){
            if(a[i] != null){
                inList +=1;
            }
        }
        return inList;
    }

    @Override
    public void sort() {
        //updates inList and checks to see if its sorted
        size();
        if(isSorted != true){
            //standard selection sort from canvas modified for generic lists
            int i, j, minIndex;
            T temp;
            for (i = 0; i < inList-1; i++) {
                minIndex = i;
                for (j = i +1; j < inList; j++) {
                    if (a[j].compareTo(a[minIndex]) < 0) {
                        minIndex = j;
                    }
                }
                    temp = a[minIndex];
                    a[minIndex] = a[i];
                    a[i] = temp;
            }
        }
        isSorted = true;
    }

    @Override
    public T remove(int index) {
        //checks for valid input
        if(index >= inList || index < 0){
            return null;
        }
        //stores removed variable and shifts everything over to fill its place
        T removed = a[index];
        a[index] = null;
        size();
        for(int i=0; i <= inList; i++){
            if(a[i] == null){
                a[i] = a[i +1];
                a[i +1] = null;
            }
        }
        size();
        isSorted = SortCheck();
        return removed;
    }

    @Override
    public void equalTo(T element) {
        //updates inList and checks for valid input
        size();
        if(element == null){}
        //changes all elements that are not equal to the element null
        else{
            for(int i=0; i < inList; i++){
                if(a[i] != element){
                    a[i] = null;
                }
            }
            //this pulls all the elements that are not null in the list to the begging keeping them in place
            for(int i=0; i < a.length; i++){
                if(a[i] != null){
                    size();
                    for(int j=0; j < inList; j++){
                        if(a[j] == null){
                            a[j] = a[i];
                            a[i] = null;
                        }
                    }
                }
            }
        }
        isSorted = SortCheck();
    }
    @Override
    public void reverse() {
        size();
        T holder;
        //loops for half the list element so there no nulls
        for(int i=0; i < inList/2; i++){
            //grabs the first element and the last non null element in the list and swaps them
            holder = a[i];
            a[i] = a[inList-i-1];
            a[inList-i-1] = holder;
        }
        isSorted = SortCheck();
    }

    @Override
    public void merge(List<T> otherList) {
        if (otherList != null) {
            ArrayList<T> other = (ArrayList<T>) otherList;
            sort();
            other.sort();
            isSorted = true;
            T[] Merged = (T[]) new Comparable[size() + other.size()];
            //everything above was standard in the list interface
            //loops through the indexes of Merged
            for (int i = 0; i < Merged.length; i++) {
                //if else branch that looks for empty lists and duplicate
                if (size() != 0 && other.size() != 0) {
                    if (a[0].compareTo(other.get(0)) < 0) {
                        Merged[i] = remove(0); //chosen element then gets removed from the original list it was in
                    } else {
                        Merged[i] = other.remove(0);
                    }
                }else if (other.size() != 0) {
                    Merged[i] = other.remove(0);
                }else {
                    Merged[i] = remove(0);
                }
            }
            //sets a to Merged after we removed all the elements from it
            a = Merged;
        }
    }
    @Override
    public boolean rotate(int n) {
        //checks for valid input and updates inList
        size();
        if(inList <= 1){
            return false;
        }
        //finds how many spaces the elements must move
        int spaces = n % inList;
        if(spaces <= 0){
            return false;
        }else{
            //moves everything one space over(last to beginning) then repeats for the number of spaces needed
            T holder;
            for(int i=0; i < spaces; i++){
                holder = a[inList-1];
                //looping backwards so its easier to handle the last element coming to the front
               for(int j=inList-1; j > 0; j--){
                   a[j] = a[j-1];
               }a[0] = holder;

            }
        }
        isSorted = SortCheck();
        return true;
    }

    @Override
    public boolean isSorted() {
        return isSorted;
    }
}
