//written by Camden Jones, JONE4307
//written by Logan Jackson, JACK1721
import java.awt.Color;
public class Circle {
    double x_pos;
    double y_pos;
    double radius;
    Color shapeColor;

    public double calculatePerimeter(){
        double perimeter = 2 * 3.14 * radius;
        //System.out.println(perimeter);
        return perimeter;
    }

    public double calculateArea(){
        double area = 3.14 * (radius * radius);
        //System.out.println(area);
        return area;
    }

    public void setColor(Color color){
        this.shapeColor = color;
    }

    public void setPos(double new_x_pos, double new_y_pos){
        this.x_pos = new_x_pos;
        this.y_pos = new_y_pos;
    }

    public void setRadius(double new_radius){
        this.radius = new_radius;
    }

    public Color getColor(){
        return shapeColor;
    }

    public double getXPos(){
        //System.out.println(x_pos);
        return x_pos;
    }

    public double getYPos(){
       // System.out.println(y_pos);
        return y_pos;
    }

    public double getRadius(){
        //System.out.println(radius);
        return radius;
    }

    public Circle(double init_x_pos, double init_y_pos, double init_radius){
        this.x_pos = init_x_pos;
        this.y_pos = init_y_pos;
        this.radius = init_radius;
    }
    public static void main(String[] args){
        Circle test = new Circle(4,5,6);
        test.getXPos();
        test.getYPos();
        test.getRadius();
        test.getColor();
        test.setPos(1,2);
        test.setRadius(3);
        test.setColor(Color.BLUE);
        test.getXPos();
        test.getYPos();
        test.getRadius();
        test.getColor();
        test.calculatePerimeter();
        test.calculateArea();

    }
}
