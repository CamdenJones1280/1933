//written by Camden Jones, JONE4307
//written by Logan Jackson, JACK1721
import java.awt.Color;
public class Rectangle {
    double x_pos;
    double y_pos;
    double width;
    double height;
    Color shapeColor;

    public double calculatePerimeter(){
        double perimeter = (2 * width) + (2 * height);
        //System.out.println(perimeter);
        return perimeter;
    }

    public double calculateArea(){
        double area = width * height;
        //System.out.println(area);
        return area;
    }

    public void setColor(Color color){
        this.shapeColor = color;
    }

    public void setPos(double new_x_pos, double new_y_pos){
        this.x_pos = new_x_pos;
        this.y_pos = new_y_pos;
    }

    public void setHeight(double new_height){
        this.height = new_height;
    }

    public void setWidth(double new_width){
        this.width = new_width;
    }

    public Color getColor(){
        return shapeColor;
    }

    public double getXPos(){
        //System.out.println(x_pos);
        return x_pos;
    }

    public double getYPos(){
        //System.out.println(y_pos);
        return y_pos;
    }

    public double getHeight(){
        //System.out.println(height);
        return height;
    }

    public double getWidth(){
        //System.out.println(width);
        return width;
    }

    public Rectangle(double init_x_pos, double init_y_pos, double init_width, double init_height) {
        this.x_pos = init_x_pos;
        this.y_pos = init_y_pos;
        this.width = init_width;
        this.height = init_height;
    }
    public static void main(String[] args) {
        Rectangle test3 = new Rectangle(1,2,3,4);
        test3.getXPos();
        test3.getYPos();
        test3.getWidth();
        test3.getHeight();
        test3.getColor();
        test3.setColor(Color.BLUE);
        test3.setPos(5,6);
        test3.setWidth(7);
        test3.setHeight(8);
        test3.getXPos();
        test3.getYPos();
        test3.getWidth();
        test3.getHeight();
        test3.getColor();
        test3.calculateArea();
        test3.calculatePerimeter();
    }
}
