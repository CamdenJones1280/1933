//written by Camden Jones, JONE4307
//written by Logan Jackson, JACK1721
import java.awt.Color;
public class Triangle {
    double x_pos;
    double y_pos;
    double base_width;
    double height;
    Color shapeColor;

    public double calculatePerimeter(){
        //find the length of the two equal sides and add them to the base
        double side = Math.sqrt((((.5 * base_width) * (.5 *base_width)) + (height * height)));
        double perimeter = (2 * side) + base_width;
        System.out.println(perimeter);
        return perimeter;
    }

    public double calculateArea(){
        double area = .5 * (base_width * height); //ask alicia to verify
        //System.out.println(area);
        return area;
    }

    public void setColor(Color color){
        this.shapeColor = color;
    }

    public void setPos(double new_x_pos, double new_y_pos){
        this.x_pos = new_x_pos;
        this.y_pos = new_y_pos;
    }

    public void setHeight(double new_height){
        this.height = new_height;
    }

    public void setWidth(double new_width){
        this.base_width = new_width;
    }

    public Color getColor(){
        return shapeColor;
    }

    public double getXPos(){
        //System.out.println(x_pos);
        return x_pos;
    }

    public double getYPos(){
        //System.out.println(y_pos);
        return y_pos;
    }

    public double getHeight(){
        //System.out.println(height);
        return height;
    }

    public double getWidth(){
        //System.out.println(base_width);
        return base_width;
    }

    public Triangle(double init_x_pos, double init_y_pos, double init_width, double init_height) {
        this.x_pos = init_x_pos;
        this.y_pos = init_y_pos;
        this.base_width = init_width;
        this.height = init_height;
    }
    public static void main(String[] args) {
        Triangle test2 = new Triangle(1,2,3,4);
        test2.getXPos();
        test2.getYPos();
        test2.getColor();
        test2.getWidth();
        test2.getHeight();
        test2.setPos(5,6);
        test2.setWidth(7);
        test2.setHeight(8);
        test2.setColor(Color.BLUE);
        test2.getXPos();
        test2.getYPos();
        test2.getColor();
        test2.getWidth();
        test2.getHeight();
        test2.calculateArea();
        test2.calculatePerimeter();

    }
}
