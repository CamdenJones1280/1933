//written by Camden Jones, JONE4307
//written by Logan Jackson, JACK1721
import java.awt.Color;
import java.util.Scanner;

public class FractalDrawer {
    private double totalArea=0;  // member variable for tracking the total area

    Color colors[] = {Color.BLUE, Color.GREEN, Color.BLACK, Color.MAGENTA, Color.ORANGE, Color.RED, Color.YELLOW, Color.CYAN};

    public FractalDrawer() {}  // contructor

    public double drawFractal(String type) {
        Canvas myCan = new Canvas(1000, 1000);
        if (type.equals("rectangle") || (type.equals("Rectangle"))){
            drawRectangleFractal(200, 200, 300, 300, Color.BLUE, myCan, 7);
        }
        else if (type.equals("triangle") || (type.equals("Triangle"))){
            drawTriangleFractal(250, 250, 375, 600, Color.BLUE, myCan, 7);
        }
        else if (type.equals("circle") || (type.equals("Circle"))) {
            drawCircleFractal(100, 400, 400, Color.BLUE, myCan, 7);
        }
        System.out.println(totalArea);
        return totalArea;
    }

    public void drawTriangleFractal(double width, double height, double x, double y, Color c, Canvas can, int level){
        if(level >= 0){
            Triangle myTriangle = new Triangle(x, y, width, height);
            myTriangle.setColor(c);
            can.drawShape(myTriangle);
            c = colors[level];
            drawTriangleFractal(width/2, height/2, ((x + ((width/2)/2))), y - height, c, can, level-1);
            drawTriangleFractal(width/2, height/2, x - width/2 , y , c, can, level-1);
            drawTriangleFractal(width/2, height/2, x + width , y , c, can, level-1);
            this.totalArea += myTriangle.calculateArea();
        }
    }

    public void drawCircleFractal(double radius, double x, double y, Color c, Canvas can, int level) {
        if(level >= 0) {
            Circle myCircle = new Circle(x, y, radius);
            myCircle.setColor(c);
            can.drawShape(myCircle);
            c = colors[level];
            drawCircleFractal(radius/2, x - radius*1.48, y, c, can, level-1);
            drawCircleFractal(radius/2, x + radius*1.48, y, c, can, level-1);
            drawCircleFractal(radius/2, x, y + radius*1.48, c, can, level-1);
            drawCircleFractal(radius/2, x, y - radius*1.48, c, can, level-1);
            this.totalArea += myCircle.calculateArea();
        }
    }

    public void drawRectangleFractal(double width, double height, double x, double y, Color c, Canvas can, int level) {
        if(level >= 0){
            Rectangle myRectangle = new Rectangle(x, y, width, height);
            myRectangle.setColor(c);
            can.drawShape(myRectangle);
            c = colors[level];
            drawRectangleFractal(width/2, height/2, x + width, y + height, c, can, level-1);
            drawRectangleFractal(width/2, height/2, x - width/2, y + height, c, can, level-1);
            drawRectangleFractal(width/2, height/2, x - width/2, y - height/2, c, can, level-1);
            drawRectangleFractal(width/2, height/2, x + width, y - height/2, c, can, level-1);
            this.totalArea += myRectangle.calculateArea();
        }
    }

    public static void main(String[] args){
        System.out.println("PLease type a shape");
        Scanner myScanner = new Scanner(System.in);
        String type = myScanner.nextLine();
        FractalDrawer whatever = new FractalDrawer();
        whatever.drawFractal(type);
    }
}

