import java.util.Scanner;
import java.io.*;
public class HashTable<T>{
    public String type = "";
    NGen<T>[] array;

    public HashTable(int l, String type){
        this.type = type;
        array = new NGen[l];
    }

    private int hash1(T key){
        //falls victim to common first two letter combinations resulting in a very long longest chain but a rather short average collisions
        int location;
        //checks to see if the string only has one char
        if(key.toString().length() == 1){
            location = key.toString().charAt(0) % array.length;
        }
        //adds first two chars of the string
        else{
            location = (key.toString().charAt(0)+key.toString().charAt(1)) % array.length;
        }
        return location;
    }

    private int hash2(T key){
        //avoids common first 2 letter combinations resulting in a slightly lower average collision and a significantly shorter the longest chain
        int location;
        //checks to see if the string only has one char
        if(key.toString().length() == 1){
            location = key.toString().charAt(0) % array.length;
        }
        //adds first and last char of the string
        else{
            location = (key.toString().charAt(0)+key.toString().charAt(key.toString().length()-1)) % array.length;
        }
        return location;
    }

    private int hash3(T key){
        //this one is more specific than the last 2, resulting a lower the longest chain and less average collisions
        //works the best for general cases
        int location;
        //checks to see if the string only has one char
        if(key.toString().length() == 1){
            location = key.toString().charAt(0) % array.length;
        }
        //adds the first, last, and middle char
        else{
            location = (key.toString().charAt(0)+key.toString().charAt(key.toString().length()-1) + key.toString().charAt(key.toString().length()/2)) % array.length;
        }
        return location;
    }

    private int SpecificHash(T key){
        //sets it apart from the other hashes by looking at spots where the words differ the most that being the middle
        //and first letters while the last portion of the location line checks length and magnifies the differnce with the times 2.
        int location;
        //checks to make sure it is more than 1 char
        if(key.toString().length() == 1){
            location = key.toString().charAt(0) % array.length;
        }
        //takes the middle letter, the length of the word minus 1 times 2, and adds the first letter
        else{
            location = ((key.toString().charAt(key.toString().length()/2) + (key.toString().length()-1) * 2 + key.toString().charAt(0)) -140 % array.length);
        }
        return location;
    }
    public void add(T item){
        int location;
        if(type.equals("general")){
            //location = hash1(item);//this decades what hash function it is using
            //location = hash2(item);//this decades what hash function it is using
            location = hash3(item);//this decades what hash function it is using
        }else if(type.equals("specific")){
            location = SpecificHash(item);//this is for specific hash
        }else{
            location = hash3(item);//this decades what hash function it is using
        }
        if(array[location] == null)
            array[location] = new NGen<>(item, null);
        else if(array[location].getData() != null){
            boolean identifier = false;
            NGen<T> temp = array[location];
            //loop that just checks for duplicates that dont need to be filed into the hash table
            while(temp != null){
                if(temp.getData().equals(item))
                    identifier = true;
                temp = temp.getNext();
            }
            if(identifier != true)
                array[location] = new NGen<>(item, array[location]);
        }
    }
    public void display(){
        //standard display function that just loops through the hash array and displays indexes and data
        int unique = 0;
        int empty = 0;
        int longChain = 0;
        for(int i = 0; i < array.length; i++){
            System.out.print(i + ": ");
            if(array[i] == null){
                empty++;
                System.out.print("0");
            }
            else if(array[i].getNext() != null){
                int currentChain = 0;
                while(array[i] != null){
                    unique++;
                    currentChain++;
                    array[i] = array[i].getNext();
                }
                System.out.print(currentChain);
                if(currentChain > longChain)
                    longChain = currentChain;
            }else {
                unique++;
                System.out.print(1);
            }
            System.out.println();
        }
        //prints for relative hash map stats
        System.out.println("Average collision length: " + unique/(array.length - empty));
        System.out.println("Longest chain: " + longChain);
        System.out.println("Unique tokens: " + unique);
        System.out.println("Empty indices: " + empty);
        System.out.println("Non empty indices: " + (array.length - empty));
    }
    public void textScan(String file) throws FileNotFoundException {
        //method that just reads off lines of a provided text
        File myObj = new File(file);
        Scanner myReader = new Scanner(myObj);
        int count = 0;

        while(myReader.hasNext()) {
            String s = myReader.next();
            this.add((T) s);
            ++count;
        }
    }

    public static void main(String[] args) throws FileNotFoundException {
        HashTable table2 = new HashTable(101, "general");//this is for general hash
        //table2.textScan("that_bad.txt");//general text
        //table2.textScan("proverbs.txt");//general text
        table2.textScan("gettysburg.txt");//general text
        table2.display();
        HashTable table1 = new HashTable(150, "specific");//this is for specific hash
        table1.textScan("keywords.txt");//specific text
        table1.display();
    }
}