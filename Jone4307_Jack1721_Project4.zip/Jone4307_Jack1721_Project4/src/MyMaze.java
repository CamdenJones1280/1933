// Names: Camden Jones, Logan Jackson
// x500s: JONE4307, JACK1721

import java.util.Random;
import java.util.Scanner;

public class MyMaze{
    Cell[][] maze;
    int startRow;
    int endRow;

    public int[] getNeighbor(int[] current, int rows, int cols){
        int[] RandNeighbor = {0,0};
        Random Rand = new Random();
        boolean valid = false;
        boolean up = true, down = true, left = true, right = true;//dead end varibles

        //picks randomly until it has a valid choice (inbounds and unvisited)
        while(valid != true) {
            int RandDirection = Rand.nextInt(4);
            //up
            if (RandDirection == 0) {
                if (current[0]+1 < rows) {
                    RandNeighbor[0] = current[0]+1;
                    RandNeighbor[1] = current[1];
                    if(maze[RandNeighbor[0]][RandNeighbor[1]].getVisited() == false){
                        valid = true;
                        maze[RandNeighbor[0]][RandNeighbor[1]].setBottom(false);//removes bottom barrier from neighbor
                    }else{
                        up = false;
                    }
                }else{
                    up = false;
                }
            }
            //down
            if (RandDirection == 1) {
                if (current[0]-1 >= 0) {
                    RandNeighbor[0] = current[0]-1;
                    RandNeighbor[1] = current[1];
                    if(maze[RandNeighbor[0]][RandNeighbor[1]].getVisited() == false){
                        valid = true;
                        maze[current[0]][current[1]].setBottom(false);//removes bottom barrier from current cell
                    }else{
                        down = false;
                    }
                }else{
                    down = false;
                }
            }
            //left
            if (RandDirection == 2) {
                if (current[1]-1 >= 0) {
                    RandNeighbor[0] = current[0];
                    RandNeighbor[1] = current[1]-1;
                    if(maze[RandNeighbor[0]][RandNeighbor[1]].getVisited() == false){
                        valid = true;
                        maze[RandNeighbor[0]][RandNeighbor[1]].setRight(false);//removes right barrier from neighbor
                    }else{
                        left = false;
                    }
                }else{
                    left = false;
                }
            }
            //right
            if (RandDirection == 3) {
                if (current[1]+1 < cols) {
                    RandNeighbor[0] = current[0];
                    RandNeighbor[1] = current[1]+1;
                    if(maze[RandNeighbor[0]][RandNeighbor[1]].getVisited() == false){
                        valid = true;
                        maze[current[0]][current[1]].setRight(false);//removes right barrier from current cell
                    }else{
                        right = false;
                    }
                }else{
                    right = false;
                }
            }
            //if these are false then there are no valid directions and ends loop
            if(up==false && down==false && left==false && right==false){
                RandNeighbor[0] = -1;
                RandNeighbor[1] = -1;
                return RandNeighbor;
            }
        }
        return RandNeighbor;
    }

    public MyMaze(int rows, int cols, int startRow, int endRow) {
        //basic constructor with a double for loop to populate the array with cell objects
        maze = new Cell[rows][cols];
        for(int i=0; i<rows; i++){
            for(int j=0; j<cols; j++){
                maze[i][j] = new Cell();
            }
        }
        this.startRow = startRow;
        this.endRow = endRow;
    }
    //generated the mazes
    public static MyMaze makeMaze(int level) {
        Random Rand = new Random();
        //easy 5X5 level
        if (level == 1) {
            //random rolls start and ending rows and then uses them when calling constructor
            int RandStartRow = Rand.nextInt(5);
            int RandEndRow = Rand.nextInt(5);
            MyMaze maze2 = new MyMaze(5, 5, RandStartRow, RandEndRow);

            //constructs new stack, adds starting space, and marks starting space as visited
            Stack1Gen<int[]> stack = new Stack1Gen<int[]>();
            stack.push(new int[]{RandStartRow, 0});
            maze2.maze[RandStartRow][0].setVisited(true);

            //while loop to loop through the stack until its empty
            while (stack.isEmpty() != true) {
                int[] next = maze2.getNeighbor(stack.top(), 5, 5);//gets a random next space
                //randomly get a neighbor and add it to the stack if its valid, pops if dead end
                if (next[0] == -1 && next[1] == -1) {
                    stack.pop();
                } else {
                    maze2.maze[next[0]][next[1]].setVisited(true);
                    stack.push(new int[]{next[0], next[1]});
                }
            }
            //sets all visit values in the maze to false as it gets done being made
            for(int i=0; i<5; i++){
                for(int j=0; j<5; j++){
                    maze2.maze[i][j].setVisited(false);
                }
            }
            //prints maze after it is done being made
            maze2.printMaze(maze2,5,5);

            //call solve method
            maze2.solveMaze(5,5);

            //prints maze again after it gets solved
            System.out.println();
            System.out.println("solved maze");
            maze2.printMaze(maze2,5,5);
        }

        //medium 5X20 level
        else if (level == 2) {
            int RandStartRow = Rand.nextInt(5);
            int RandEndRow = Rand.nextInt(5);
            MyMaze maze2 = new MyMaze(5, 20, RandStartRow, RandEndRow);

            //constructs new stack, adds starting space, and marks starting space as visited
            Stack1Gen<int[]> stack = new Stack1Gen<int[]>();
            stack.push(new int[]{RandStartRow, 0});
            maze2.maze[RandStartRow][0].setVisited(true);

            //while loop to loop through the stack until its empty
            while (stack.isEmpty() != true) {
                int[] next = maze2.getNeighbor(stack.top(),5,20);//gets a random next space
                //randomly get a neighbor and add it to the stack if its valid, pops if dead end
                if (next[0] == -1 && next[1] == -1) {
                    stack.pop();
                } else {
                    maze2.maze[next[0]][next[1]].setVisited(true);
                    stack.push(new int[]{next[0], next[1]});
                }
            }
            //sets all visit values in the maze to false as it gets done being made
            for(int i=0; i<5; i++){
                for(int j=0; j<20; j++){
                    maze2.maze[i][j].setVisited(false);
                }
            }
            //prints maze after it is done being made
            maze2.printMaze(maze2,5,20);

            //call solve method
            maze2.solveMaze(5,20);

            //prints maze again after it gets solved
            System.out.println();
            System.out.println("solved maze");
            maze2.printMaze(maze2,5,20);
        }

        //hard 20X20 level
        else if(level == 3){
            int RandStartRow = Rand.nextInt(20);
            int RandEndRow = Rand.nextInt(20);
            MyMaze maze2 = new MyMaze(20,20,RandStartRow,RandEndRow);

            //constructs new stack, adds starting space, and marks starting space as visited
            Stack1Gen<int[]> stack = new Stack1Gen<int[]>();
            stack.push(new int[]{RandStartRow, 0});
            maze2.maze[RandStartRow][0].setVisited(true);

            //while loop to loop through the stack until its empty
            while(stack.isEmpty() != true) {
                int[] next = maze2.getNeighbor(stack.top(),20,20);//gets a random next space
                //randomly get a neighbor and add it to the stack if its valid, pops if dead end
                if (next[0] == -1 && next[1] == -1) {
                    stack.pop();
                } else {
                    maze2.maze[next[0]][next[1]].setVisited(true);
                    stack.push(new int[]{next[0], next[1]});
                }
            }
            //sets all visit values in the maze to false as it gets done being made
            for(int i=0; i<20; i++){
                for(int j=0; j<20; j++){
                    maze2.maze[i][j].setVisited(false);
                }
            }
            //prints maze after it is done being made
            maze2.printMaze(maze2,20,20);

            //call solve method
            maze2.solveMaze(20,20);

            //prints maze again after it gets solved
            System.out.println();
            System.out.println("solved maze");
            maze2.printMaze(maze2,20,20);
        }
        //else branch that catches invalid inputs
        else{
            System.out.println("no valid valid level selection has been made");
        }
        return null;
    }


    public void printMaze(MyMaze maze2, int rows, int cols) {
        int printrows=0;
        int realrow=rows;
        for (int i = rows*2; i >= 0; i--) {//has to index backwards because the bottom row appears first but cols stay same
            for (int j = 0; j < cols; j++) {
                //top row of barriers
                if(printrows == 0 && j == cols-1){
                    System.out.print("| --- |");
                }else if(printrows == 0){
                    System.out.print("| --- ");
                }
                //start and left boarder
                if(j == 0){
                    if(realrow == startRow && printrows % 2 == 1){
                        System.out.print(" ");
                        startRow = realrow;
                    }else if(realrow == 5 && printrows == 1 && startRow == 0){
                        System.out.print(" ");
                        startRow = realrow;
                    }else if(j == 0 && printrows != 0) {
                        System.out.print("|");
                    }
                }
                //bottom barrier setters
                if(printrows % 2 == 0 && printrows != 0){
                    if(maze[realrow][j].getBottom() == true){
                        System.out.print(" --- |");
                    }else if(maze[realrow][j].getBottom() == false){
                        System.out.print("     |");
                    }
                }
                //right barrier setters
                if(printrows % 2 == 1){
                    if(maze[realrow-1][j].getRight() == true){
                        //handles the case where the right barrier is the exit of the maze
                        if(realrow-1 == endRow && j == cols-1){
                            if(maze[realrow-1][j].getVisited() == true){
                                System.out.print("  *   ");
                            }else {
                                System.out.print("      ");
                            }
                        }else{
                            if(maze[realrow-1][j].getVisited() == true){
                                System.out.print("  *  |");
                            }else {
                                System.out.print("     |");
                            }
                        }
                    }else if(maze[realrow-1][j].getRight() == false){
                        if(maze[realrow-1][j].getVisited() == true) {
                            System.out.print("  *   ");
                        }else {
                            System.out.print("      ");
                        }
                    }
                }
            }
            printrows++;
            if(printrows % 2 == 0 && printrows != 0){
                realrow--;
            }
            System.out.println();
        }
    }

    /* TODO: Solve the maze using the algorithm found in the writeup. */
    public void solveMaze(int rows,int cols) {
        //constructs and initializes queue with starting space
        Q1Gen<int[]> queue = new Q1Gen<int[]>();
        queue.add(new int[]{startRow-1, 0});
        //maze[startRow][0].setVisited(true);

        boolean endfound = false;//loop ending variable
        int[] current;

        //while loop that ends when end is found or queue is empty
        while(queue.length() != 0 && endfound == false){
            current = queue.remove();
            maze[current[0]][current[1]].setVisited(true);
            if(current[0] == endRow && current[1] == cols-1){
                endfound = true;
            }
            //else branch adds every reachable neighbor to the queue
            else{
                //up
                if(current[0]+1 < rows){
                    if(maze[current[0]+1][current[1]].getBottom() == false && maze[current[0]+1][current[1]].getVisited() == false){
                        queue.add(new int[]{current[0]+1, current[1]});
                    }
                }
                //down
                if(current[0]-1 >= 0){
                    if(maze[current[0]][current[1]].getBottom() == false && maze[current[0]-1][current[1]].getVisited() == false){
                        queue.add(new int[]{current[0]-1, current[1]});
                    }
                }
                //left
                if(current[1]-1 >= 0){
                    if(maze[current[0]][current[1]-1].getRight() == false && maze[current[0]][current[1]-1].getVisited() == false){
                        queue.add(new int[]{current[0], current[1]-1});
                    }
                }
                //right
                if(current[1]+1 < cols){
                    if(maze[current[0]][current[1]].getRight() == false && maze[current[0]][current[1]+1].getVisited() == false){
                        queue.add(new int[]{current[0], current[1]+1});
                    }
                }
            }
        }
    }

    public static void main(String[] args){
        /* Use scanner to get user input for maze level, then make and solve maze */
        Scanner scanner = new Scanner(System.in);
        System.out.println("What level of maze would you like, small, medium, or large.");
        String s = scanner.nextLine();
        if(s.equals("small") || s.equals("Small")){
            makeMaze(1);
        }
        else if(s.equals("medium") || s.equals("Medium")){
            makeMaze(2);
        }
        else if(s.equals("large") || s.equals("Large")){
            makeMaze(3);
        }
        else{
            System.out.println("Invalid input");
        }
    }
}
